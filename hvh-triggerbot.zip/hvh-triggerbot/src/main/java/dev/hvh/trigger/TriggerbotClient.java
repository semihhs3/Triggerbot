package dev.hvh.trigger;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class TriggerbotClient implements ClientModInitializer {
    public static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        TriggerConfig.load();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hvhtrigger.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.hvhtrigger"
        ));

        // R tuşu -> menüyü aç
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new TriggerMenuScreen());
                }
            }
        });

        // Her frame kontrol (ms hassasiyetli delay için)
        WorldRenderEvents.START.register(context -> Triggerbot.update(MinecraftClient.getInstance()));
    }
}
