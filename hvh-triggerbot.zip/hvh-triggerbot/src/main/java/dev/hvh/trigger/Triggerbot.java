package dev.hvh.trigger;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class Triggerbot {
    private static long readySince = -1;
    private static long lastAttack = 0;

    /** Her frame çağrılır. */
    public static void update(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;

        if (!TriggerConfig.enabled
                || player == null
                || mc.world == null
                || mc.interactionManager == null
                || mc.currentScreen != null) {
            readySince = -1;
            return;
        }

        HitResult hit = mc.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.ENTITY) {
            readySince = -1;
            return;
        }

        Entity target = ((EntityHitResult) hit).getEntity();
        if (!isValid(player, target) || player.isUsingItem()) {
            readySince = -1;
            return;
        }

        if (TriggerConfig.waitCooldown && player.getAttackCooldownProgress(0.0f) < 1.0f) {
            readySince = -1;
            return;
        }

        long now = System.currentTimeMillis();
        if (readySince < 0) readySince = now;

        if (now - readySince < TriggerConfig.delayMs) return; // delay dolmadı
        if (now - lastAttack < 50) return;                    // spam koruması

        mc.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);

        lastAttack = now;
        readySince = -1;
    }

    private static boolean isValid(ClientPlayerEntity self, Entity target) {
        if (!(target instanceof LivingEntity living)) return false;
        if (living == self || !living.isAlive()) return false;
        if (living instanceof ArmorStandEntity) return false;

        if (living instanceof PlayerEntity other) {
            return !other.isSpectator();
        }
        return !TriggerConfig.playersOnly;
    }
}
