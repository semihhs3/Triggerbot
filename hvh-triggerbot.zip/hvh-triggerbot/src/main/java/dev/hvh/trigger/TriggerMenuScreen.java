package dev.hvh.trigger;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class TriggerMenuScreen extends Screen {

    public TriggerMenuScreen() {
        super(Text.literal("HvH Triggerbot"));
    }

    @Override
    protected void init() {
        int w = 200;
        int h = 20;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - 60;

        addDrawableChild(ButtonWidget.builder(enabledText(), b -> {
            TriggerConfig.enabled = !TriggerConfig.enabled;
            b.setMessage(enabledText());
        }).dimensions(x, y, w, h).build());

        addDrawableChild(new DelaySlider(x, y + 26, w, h));

        addDrawableChild(ButtonWidget.builder(cooldownText(), b -> {
            TriggerConfig.waitCooldown = !TriggerConfig.waitCooldown;
            b.setMessage(cooldownText());
        }).dimensions(x, y + 52, w, h).build());

        addDrawableChild(ButtonWidget.builder(playersText(), b -> {
            TriggerConfig.playersOnly = !TriggerConfig.playersOnly;
            b.setMessage(playersText());
        }).dimensions(x, y + 78, w, h).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Kapat"), b -> close())
                .dimensions(x, y + 110, w, h).build());
    }

    private static Text onOff(String label, boolean value) {
        return Text.literal(label + ": ")
                .append(Text.literal(value ? "AÇIK" : "KAPALI")
                        .formatted(value ? Formatting.GREEN : Formatting.RED));
    }

    private static Text enabledText() {
        return onOff("Triggerbot", TriggerConfig.enabled);
    }

    private static Text cooldownText() {
        return onOff("Cooldown Bekle", TriggerConfig.waitCooldown);
    }

    private static Text playersText() {
        return onOff("Sadece Oyuncular", TriggerConfig.playersOnly);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 85, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (TriggerbotClient.menuKey != null && TriggerbotClient.menuKey.matchesKey(keyCode, scanCode)) {
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        TriggerConfig.save();
    }

    private static class DelaySlider extends SliderWidget {
        DelaySlider(int x, int y, int width, int height) {
            super(x, y, width, height, Text.empty(), TriggerConfig.delayMs / (double) TriggerConfig.MAX_DELAY);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            int ms = (int) Math.round(this.value * TriggerConfig.MAX_DELAY);
            setMessage(Text.literal("Delay: " + ms + " ms"));
        }

        @Override
        protected void applyValue() {
            TriggerConfig.delayMs = (int) Math.round(this.value * TriggerConfig.MAX_DELAY);
        }
    }
}
