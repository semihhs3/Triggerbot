package dev.hvh.trigger;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class TriggerConfig {
    public static final int MAX_DELAY = 500;

    public static boolean enabled = true;
    public static int delayMs = 100;
    public static boolean waitCooldown = true;
    public static boolean playersOnly = true;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("hvhtrigger.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (InputStream in = Files.newInputStream(f)) {
            Properties p = new Properties();
            p.load(in);
            enabled = Boolean.parseBoolean(p.getProperty("enabled", "true"));
            waitCooldown = Boolean.parseBoolean(p.getProperty("waitCooldown", "true"));
            playersOnly = Boolean.parseBoolean(p.getProperty("playersOnly", "true"));
            int d = Integer.parseInt(p.getProperty("delayMs", "100"));
            delayMs = Math.max(0, Math.min(MAX_DELAY, d));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        try (OutputStream out = Files.newOutputStream(file())) {
            Properties p = new Properties();
            p.setProperty("enabled", String.valueOf(enabled));
            p.setProperty("waitCooldown", String.valueOf(waitCooldown));
            p.setProperty("playersOnly", String.valueOf(playersOnly));
            p.setProperty("delayMs", String.valueOf(delayMs));
            p.store(out, "HvH Triggerbot config");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
